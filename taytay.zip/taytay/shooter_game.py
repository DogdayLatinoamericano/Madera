from pygame import *
from random import randint
from time import time as timer

font.init()
font1 = font.Font(None, 80)
win = font1.render('¡GANASTE!', True, (255, 255, 255))
lose = font1.render('¡PERDISTE!', True, (180, 0, 0))
font2 = font.Font(None, 36)

mixer.init()
fire_sound = mixer.Sound('wood2.ogg')

img_ast = "kelce.png"
img_back = "background.jpg"
img_bullet = "wood.png" 
img_hero = "taytay.png"
img_enemy = "kelce.png"

score = 0
goal = 20
lost = 0
max_lost = 25
life = 3

# Clase padre para otros objetos
class GameSprite(sprite.Sprite):
    def __init__(self, player_image, player_x, player_y, size_x, size_y, player_speed):
        sprite.Sprite.__init__(self)
        self.image = transform.scale(image.load(player_image), (size_x, size_y))
        self.speed = player_speed
        self.rect = self.image.get_rect()
        self.rect.x = player_x
        self.rect.y = player_y

    def reset(self):
        window.blit(self.image, (self.rect.x, self.rect.y))

# Clase del jugador principal
class Player(GameSprite):
    def update(self):
        keys = key.get_pressed()
        if keys[K_LEFT] and self.rect.x > 5:
            self.rect.x -= self.speed
        if keys[K_RIGHT] and self.rect.x < win_width - 80:
            self.rect.x += self.speed
            
    def fire(self):
        bullet = Bullet(img_bullet, self.rect.centerx, self.rect.top, 15, 20, -15)
        bullets.add(bullet)

class Enemy(GameSprite):
    def update(self):
        self.rect.y += self.speed
        global lost
        if self.rect.y > win_height:
            self.rect.x = randint(80, win_width - 80)
            self.rect.y = 0
            lost += 1

class Bullet(GameSprite):
    def update(self):
        self.rect.y += self.speed
        if self.rect.y < 0:
            self.kill()

win_width = 700
win_height = 500
display.set_caption("Tirador")
window = display.set_mode((win_width, win_height))
background = transform.scale(image.load(img_back), (win_width, win_height))

ship = Player(img_hero, 5, win_height - 100, 80, 100, 10)

monsters = sprite.Group()
for i in range(1, 6):
    monster = Enemy(img_enemy, randint(80, win_width - 80), -40, 80, 50, randint(1, 5))
    monsters.add(monster)

asteroids = sprite.Group()
for i in range(1, 3):
    asteroid = Enemy(img_ast, randint(30, win_width - 30), -40, 80, 50, randint(1, 7))
    asteroids.add(asteroid)

bullets = sprite.Group()
finish = False
run = True

rel_time = False
num_fire = 0
last_time = 0

while run:
    for e in event.get():
        if e.type == QUIT:
            run = False
        elif e.type == KEYDOWN:
            if e.key == K_SPACE: # Ahora solo dispara con la barra espaciadora
                if num_fire < 5 and not rel_time:
                    num_fire += 1
                    fire_sound.play()
                    ship.fire()

                if num_fire >= 5 and not rel_time:
                    last_time = timer()
                    rel_time = True
                
    if not finish:
        window.blit(background, (0, 0))

        # Actualizar posiciones
        ship.update()
        monsters.update()
        bullets.update()
        asteroids.update()

        # Dibujar los sprites en pantalla
        ship.reset()
        monsters.draw(window)
        bullets.draw(window)
        asteroids.draw(window) # Agregado: para que se vean los asteroides

        # Lógica de recarga corregida
        if rel_time:
            now_time = timer()
            if now_time - last_time < 1:
                reload_text = font2.render('Espera, recargando...', 1, (150, 0, 0))
                window.blit(reload_text, (260, 460))
            else:
                num_fire = 0
                rel_time = False

        collides = sprite.groupcollide(monsters, bullets, True, True)
        for c in collides:
            score += 1
            monster = Enemy(img_enemy, randint(80, win_width - 80), -40, 80, 50, randint(1, 5))
            monsters.add(monster)
            
        # Sistema de colisiones y vidas mejorado
        if sprite.spritecollide(ship, monsters, False) or lost >= max_lost:
            life -= 1
            if life <= 0:
                finish = True
                window.blit(lose, (200, 200))
            else:
                # Reinicia la posición de los enemigos si aún te quedan vidas
                for m in monsters:
                    m.rect.y = -40
                    m.rect.x = randint(80, win_width - 80)
                lost = 0
            
        if score >= goal:
            finish = True
            window.blit(win, (200, 200))

        # Mostrar el puntaje y los enemigos que pasaron
        text_score = font2.render("Puntaje: " + str(score), 1, (255, 255, 255))
        window.blit(text_score, (10, 20))
        
        text_lose = font2.render("Fallados: " + str(lost), 1, (255, 255, 255))
        window.blit(text_lose, (10, 50))

        # Lógica y dibujado de las vidas
        if life == 3:
            life_color = (0, 150, 0)
        elif life == 2:
            life_color = (150, 150, 0)
        else:
            life_color = (150, 0, 0)
            
        text_life = font1.render(str(life), 1, life_color)
        window.blit(text_life, (650, 10))

        display.update()

    else:
        # Pantalla final. Espera 3 segundos y cierra el juego.
        display.update()
        time.delay(3000)
        run = False 

    time.delay(50)